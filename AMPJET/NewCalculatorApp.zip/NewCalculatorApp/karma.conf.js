// Karma configuration
// Generated on Sun Jan 12 2020 16:36:36 GMT+0530 (India Standard Time)

module.exports = function(config) {
  config.set({
    basePath: '',
    frameworks: [ 'jasmine'],
    karmaTypescriptConfig: {
      tsconfig: "./tsconfig.json",
    },
    files: [
      { pattern: './spec/*[sS]pec.ts'}
    ],
    plugins: [             
      'karma-jasmine',
      'karma-requirejs',
      'karma-chrome-launcher',
      'karma-coverage'
    ],
    exclude: [
    ],
    preprocessors: [
      { './spec/*[sS]pec.ts' : ['karma']}
    ],
    coverageReporter: {
      reporters: [
        {type: "ts"},
        {type: "html"},
        {type: "text"},
      ],
    },
    reporters: [ 'spec' ],
    port: 9876,
    colors: true,
    logLevel: config.LOG_INFO,
    autoWatch: true,
    browsers: ['Chrome'],
    singleRun: false,
    concurrency: Infinity
  })
}
