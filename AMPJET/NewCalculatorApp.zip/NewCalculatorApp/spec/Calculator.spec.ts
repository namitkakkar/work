import {Calculator} from "../src/ts/viewModels/Calculator";

describe("Calculator addition function return value", () => {
    it("Should be defined.", () =>{
        const calc = new Calculator();
        expect(calc.addition(1,2)).toBeDefined("The function addition() should be defined");
    });

    it("Should return 3", () => {
        const calc = new Calculator();
        expect(calc.addition(1,2)).toEqual(3);
    });

    it("Should't return blank.", () => {
        const calc = new Calculator();
        expect(calc.subtraction(1,2)).toEqual(-1);
    });
})