"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ko = require("knockout");
const appController_1 = require("./appController");
require("ojs/ojknockout");
require("ojs/ojbutton");
require("ojs/ojtoolbar");
require("ojs/ojmenu");
class Root {
    constructor() {
        // if running in a hybrid (e.g. Cordova) environment, we need to wait for the deviceready
        // event before executing any code that might interact with Cordova APIs or plugins.
        if (document.body.classList.contains("oj-hybrid")) {
            document.addEventListener("deviceready", this.init);
        }
        else {
            this.init();
        }
    }
    init() {
        appController_1.default.loadModule();
        // bind your ViewModel for the content of the whole page body.
        ko.applyBindings(appController_1.default, document.getElementById("globalBody"));
    }
}
exports.default = Root;
//# sourceMappingURL=root.js.map