"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class AdvancedActivityUtil {
    static getKeyValueObj(key, value) {
        const data = {
            key: key,
            value: value
        };
        return data;
    }
}
exports.AdvancedActivityUtil = AdvancedActivityUtil;
//# sourceMappingURL=AdvancedActivityUtil.js.map