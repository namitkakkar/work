"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class AdvancedActivityConstants {
}
exports.AdvancedActivityConstants = AdvancedActivityConstants;
AdvancedActivityConstants.EVENT_TYPE = "EventType";
AdvancedActivityConstants.VAL_DATE = "ValuationDate";
AdvancedActivityConstants.LAND_VALUE = "LandValue";
AdvancedActivityConstants.IMPROVEMENT_VALUE = "ImprovementValue";
AdvancedActivityConstants.PERSONALPROPERTY_VALUE = "PersonalPropertyValue";
AdvancedActivityConstants.FIXTURE_VALUE = "FixtureValue";
//# sourceMappingURL=AdvancedActivityConstants.js.map