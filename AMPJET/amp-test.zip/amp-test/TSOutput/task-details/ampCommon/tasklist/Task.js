"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ko = require("knockout");
const TaskDetailsFacade_1 = require("./facade/TaskDetailsFacade");
class Task {
    constructor() {
        let self = this;
        self.workUnitDetailsList = ko.observableArray([]);
        self.activityStageArray = ko.observableArray([]);
        self.taskDetailsFacade = new TaskDetailsFacade_1.TaskDetailsFacade();
    }
    getWorkUnitDetails(wuNumber) {
        let self = this;
        self.taskDetailsFacade.getWorkUnitDetails(wuNumber, function (data) {
            self.workUnitDetailsList(data);
            self.filterActivities('Records Maintenance');
        });
    }
    saveWorkUnitDetails() {
        let self = this;
        self.taskDetailsFacade.saveWorkUnitDetails(self.workUnitDetailsList(), function (data) {
        });
    }
    filterActivities(stageName) {
        let self = this;
        if (self.workUnitDetailsList() !== undefined && self.workUnitDetailsList().length > 0) {
            self.activityStageArray(self.taskDetailsFacade.filterActivities(stageName, self.workUnitDetailsList()[0].WU_AO[0].WU_ACTIVITIES));
        }
    }
    static getInstance() {
        if (!Task.instance) {
            Task.instance = new Task();
            console.log("New Task Instance");
        }
        else {
            console.log("Old Task Instance");
        }
        return Task.instance;
    }
}
exports.Task = Task;
//# sourceMappingURL=Task.js.map