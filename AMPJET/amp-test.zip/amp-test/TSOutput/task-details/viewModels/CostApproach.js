"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ko = require("knockout");
require("ojs/ojknockout");
require("ojs/ojbutton");
require("ojs/ojinputtext");
require("ojs/ojselectsingle");
require("ojs/ojdatetimepicker");
require("ojs/ojformlayout");
require("ojs/ojbutton");
const AdvancedActivityUtil_1 = require("../util/AdvancedActivityUtil");
const AdvancedActivityConstants_1 = require("../util/AdvancedActivityConstants");
const ArrayDataProvider = require("ojs/ojarraydataprovider");
class CostApproach {
    constructor() {
        this.activityName = ko.observable();
        this.eventType = ko.observable('CH');
        this.valuationDate = ko.observable();
        this.landValue = ko.observable(0);
        this.improvementValue = ko.observable(0);
        this.ppValue = ko.observable(0);
        this.fixtureValue = ko.observable(0);
        this.totalRealProperty = ko.observable(0);
        this.fixtureTotal = ko.observable(0);
        this.PAYLOAD_LIST = ko.observableArray([]);
        this.loadCostApproachDetails = (activityPayload) => {
            let self = this;
            if (activityPayload && (activityPayload.ValueSetList && activityPayload.ValueSetList.length > 0)) {
                let keyPairList = activityPayload.ValueSetList[0].ValueSet;
                if (keyPairList && keyPairList.length > 0) {
                    for (const val in keyPairList) {
                        switch (keyPairList[val].key) {
                            case 'EventType': {
                                self.eventType(keyPairList[val].value);
                                break;
                            }
                            case 'ValuationDate': {
                                self.valuationDate(keyPairList[val].value);
                                break;
                            }
                            case 'LandValue': {
                                self.landValue(keyPairList[val].value);
                                break;
                            }
                            case 'ImprovementValue': {
                                self.improvementValue(keyPairList[val].value);
                                break;
                            }
                            case 'PersonalPropertyValue': {
                                self.ppValue(keyPairList[val].value);
                                break;
                            }
                            case 'FixtureValue': {
                                self.fixtureValue(keyPairList[val].value);
                                break;
                            }
                            default: {
                                console.log("Key Not Found");
                                break;
                            }
                        }
                    }
                }
            }
            else {
                self.eventType('');
                self.valuationDate();
                self.landValue(0);
                self.improvementValue(0);
                self.ppValue(0);
                self.fixtureValue(0);
            }
        };
        this.prepareCostApproachPayload = () => {
            let self = this;
            const activityPaylaodData = {
                name: "Cost Approach",
                ValueSetList: []
            };
            let keyValueList = [];
            keyValueList.push(AdvancedActivityUtil_1.AdvancedActivityUtil.getKeyValueObj(AdvancedActivityConstants_1.AdvancedActivityConstants.EVENT_TYPE, self.eventType()));
            keyValueList.push(AdvancedActivityUtil_1.AdvancedActivityUtil.getKeyValueObj(AdvancedActivityConstants_1.AdvancedActivityConstants.VAL_DATE, self.valuationDate()));
            keyValueList.push(AdvancedActivityUtil_1.AdvancedActivityUtil.getKeyValueObj(AdvancedActivityConstants_1.AdvancedActivityConstants.LAND_VALUE, self.landValue()));
            keyValueList.push(AdvancedActivityUtil_1.AdvancedActivityUtil.getKeyValueObj(AdvancedActivityConstants_1.AdvancedActivityConstants.IMPROVEMENT_VALUE, self.improvementValue()));
            keyValueList.push(AdvancedActivityUtil_1.AdvancedActivityUtil.getKeyValueObj(AdvancedActivityConstants_1.AdvancedActivityConstants.PERSONALPROPERTY_VALUE, self.ppValue()));
            keyValueList.push(AdvancedActivityUtil_1.AdvancedActivityUtil.getKeyValueObj(AdvancedActivityConstants_1.AdvancedActivityConstants.FIXTURE_VALUE, self.fixtureValue()));
            const valuesetList = {
                name: "Cost Approach",
                ValueSet: keyValueList
            };
            activityPaylaodData.ValueSetList.push(valuesetList);
            return activityPaylaodData;
        };
        let self = this;
        let browsers = [
            { value: 'IE', label: 'Internet Explorer' },
            { value: 'FF', label: 'Firefox' },
            { value: 'CH', label: 'Chrome' },
            { value: 'OP', label: 'Opera' },
            { value: 'SA', label: 'Safari' }
        ];
        self.browsersDP = new ArrayDataProvider(browsers, { keyAttributes: 'value' });
        ko.computed(() => {
            let self = this;
            self.totalRealProperty(+self.landValue() + +self.improvementValue());
            self.fixtureTotal(+self.ppValue() + +self.fixtureValue());
        });
    }
}
exports.default = new CostApproach();
//# sourceMappingURL=CostApproach.js.map