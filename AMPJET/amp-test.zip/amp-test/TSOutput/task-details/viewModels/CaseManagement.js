"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ko = require("knockout");
require("ojs/ojnavigationlist");
require("ojs/ojknockout");
const Task_1 = require("../ampCommon/tasklist/Task");
require("ojs/ojmodule-element");
const ModuleUtils = require("ojs/ojmodule-element-utils");
class caseManagementViewModel {
    constructor() {
        this.stage = ko.observable('Record Maintainance');
        let self = this;
        self.task = ko.observable(Task_1.Task.getInstance());
        self.activityModuleConfig = ko.observable({ "view": [], "viewModel": null });
        self.stageLinks = ko.observableArray([
            { id: 'CaseManagement', label: 'Case Management' },
            { id: 'RecordMaintainance', label: 'Records Maintenance' },
            { id: 'EligibilityDetermination', label: 'Eligibility Determination' },
            { id: 'Appraisal', label: 'Appraisal' },
            { id: 'Assessment', label: 'Assessment' }
        ]);
        let activityPromise = Promise.all([
            ModuleUtils.createView({ "viewPath": "views/Activity.html" }),
            ModuleUtils.createViewModel({ "viewModelPath": "viewModels/Activity" })
        ]);
        activityPromise.then((values) => {
            self.activityModuleConfig({ "view": values[0], "viewModel": values[1].default });
        });
        self.stageChangeAction = (event) => {
            self.task().filterActivities(self.stage());
        };
    }
}
exports.default = caseManagementViewModel;
//# sourceMappingURL=CaseManagement.js.map