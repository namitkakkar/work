"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class headerViewModel {
    constructor() {
    }
}
exports.default = headerViewModel;
//# sourceMappingURL=Header.js.map