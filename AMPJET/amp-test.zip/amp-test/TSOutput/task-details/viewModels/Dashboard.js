"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ko = require("knockout");
const Router = require("ojs/ojrouter");
const ArrayDataProvider = require("ojs/ojarraydataprovider");
require("ojs/ojknockout");
require("ojs/ojmodule-element");
require("ojs/ojnavigationlist");
require("ojs/ojknockout");
require("ojs/ojselectcombobox");
require("ojs/ojtable");
const Task_1 = require("../ampCommon/tasklist/Task");
const ModuleUtils = require("ojs/ojmodule-element-utils");
require("ojs/ojpopup");
require("ojs/ojbutton");
const ModuleElementUtils = require("ojs/ojmodule-element-utils");
class DashboardViewModel {
    constructor() {
        this.onSave = () => {
            console.log("Calling Global Save");
            this.task().saveWorkUnitDetails();
        };
        let self = this;
        self.task = ko.observable(Task_1.Task.getInstance());
        self.router = Router.rootInstance;
        self.workUnitNumber = "WU1910-1090122";
        self.selectedAIN = ko.observable();
        self.workUnitDataProvider = ko.observable();
        self.ainDataSource = ko.observableArray([]);
        self.ainArray = ko.observableArray();
        self.task = ko.observable(Task_1.Task.getInstance());
        self.moduleConfig = ko.observable({ view: [], viewModel: null });
        let casePromise = Promise.all([
            ModuleUtils.createView({ "viewPath": "views/CaseManagement.html" }),
            ModuleUtils.createViewModel({ "viewModelPath": "viewModels/CaseManagement" })
        ]);
        casePromise.then((values) => {
            self.moduleConfig({ "view": values[0], "viewModel": values[1].default });
        });
        let navData = [
            new NavDataItem({ name: "Case Management", id: "CaseManagement", iconClass: "oj-navigationlist-item-icon demo-icon-font-24 demo-chart-icon-24" }),
            new NavDataItem({ name: "Record Maintainance", id: "RecordMaintainance", iconClass: "oj-navigationlist-item-icon demo-icon-font-24 demo-chart-icon-24" }),
            new NavDataItem({ name: "Eligibility Determination", id: "EligibilityDetermination", iconClass: "oj-navigationlist-item-icon demo-icon-font-24 demo-chart-icon-24" }),
            new NavDataItem({ name: "Appraisal", id: "Appraisal", iconClass: "oj-navigationlist-item-icon demo-icon-font-24 demo-chart-icon-24" }),
            new NavDataItem({ name: "Assessment", id: "Assessment", iconClass: "oj-navigationlist-item-icon demo-icon-font-24 demo-chart-icon-24" }),
        ];
        self.navDataSource = new ArrayDataProvider(navData, { idAttribute: "id" });
        self.workUnitColumnArray = ko.observableArray([
            new ColumnArray({ "headerText": "Business Event Date", "field": "CREATED_DATE" }),
            new ColumnArray({ "headerText": "Category", "field": "CATEGORY" }),
            new ColumnArray({ "headerText": "Sub Category", "field": "SUBCATEGORY" }),
            new ColumnArray({ "headerText": "Work Unit Type", "field": "WORK_UNIT_TYPE" }),
            new ColumnArray({ "headerText": "Work Unit Status", "field": "STATUS" }),
            new ColumnArray({ "headerText": "Assignment Pool", "field": "ASSIGNMENT_POOL" }),
            new ColumnArray({ "headerText": "AAU Name", "field": "" }),
            new ColumnArray({ "headerText": "AAU Relationship Type", "field": "" })
        ]);
        ko.computed(() => {
            if (self.task().workUnitDetailsList() !== undefined && self.task().workUnitDetailsList().length > 0) {
                self.workUnitDataProvider(new ArrayDataProvider(self.task().workUnitDetailsList(), { idAttribute: "WU_NUMBER" }));
                self.ainArray(self.task().workUnitDetailsList()[0].WU_AO);
                self.ainArray().forEach((val) => {
                    self.ainDataSource.push({ label: val.AIN, value: val.AIN });
                });
                self.selectedAIN(self.ainDataSource()[0].value);
            }
        });
        this.remarksPopupModuleConfig = ko.observable({ view: [], viewModel: null });
        let remarksPromise = Promise.all([
            ModuleElementUtils.createView({ "viewPath": "views/Remarks.html" }),
            ModuleElementUtils.createViewModel({ "viewModelPath": "viewModels/Remarks" })
        ]);
        remarksPromise.then((values) => {
            this.remarksPopupModuleConfig({ "view": values[0], "viewModel": values[1].default });
        });
    }
    // public openListener() {
    //   let popup = document.getElementById('popup1') as ojPopup;
    //   popup.open('#btnGo');
    // };
    addRemarks() {
        // let popup = document.getElementById('remarksPopup') as ojPopup;
        // popup.open('#btnAddRemarks');
        this.openRemarksPopUp();
    }
    ;
    openRemarksPopUp() {
        // alert("hello");
        let popup = document.getElementById('remarksPopup');
        popup.open('#btnAddRemarks');
    }
    connected() {
    }
}
class NavDataItem {
    constructor({ id, name, iconClass }) {
        this.id = id;
        this.name = name;
        this.iconClass = iconClass;
    }
}
class ColumnArray {
    constructor({ headerText, field }) {
        this.headerText = headerText;
        this.field = field;
        this.resizable = "enabled";
    }
}
exports.default = DashboardViewModel;
//# sourceMappingURL=Dashboard.js.map