"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ko = require("knockout");
require("ojs/ojtable");
require("ojs/ojmodel");
require("ojs/ojlabel");
require("ojs/ojbutton");
require("ojs/ojinputtext");
require("ojs/ojdatetimepicker");
require("ojs/ojinputnumber");
require("ojs/ojcore");
// import { IRemarks } from "../models/interfaces/IRemarks";
const ArrayDataProvider = require("ojs/ojarraydataprovider");
require("ojs/ojdialog");
class RemarksViewModel {
    constructor() {
        this.remarksObservableArray = ko.observableArray([]);
        this.remarksDataObservable = ko.observable();
        this.workUnitNumber = ko.observable("76272872");
        this.noteslength = ko.observable();
        var self = this;
        fetch("http://iampwtd201.assessor.lacounty.gov:7777/soa-infra/resources/amp/RemarkAPIs/RemarkRestAPIs/GetRemarks?ModuleName=GCM_WU_INST&ParentId=693", {
        //        headers: {
        //   "Access-Control-Allow-Origin":"*",
        //   "content-type": "application/json",
        //   // "Authorization":"Basic QzE3ODY2MjpQYXNzd29yZDEyMw=="
        // }
        }).then(res => res.json())
            .then(res => {
            console.log(res);
            console.log(res.WU_NOTES);
            const resResult = res.WU_NOTES;
            this.remarksObservableArray(resResult);
            console.log(this.remarksObservableArray());
            this.remarksDataObservable(new ArrayDataProvider(this.remarksObservableArray, { keyAttributes: 'REMARKS_ID' }));
            this.remarksObservableArray(resResult);
            console.log(this.remarksObservableArray());
            this.noteslength(this.remarksObservableArray().length);
        }).catch(error => {
            console.log("ERROR");
            console.log(error);
        });
        //   console.log( new Date("2016-01-17T08:44:29+0100"));
    }
    /**
     * Optional ViewModel method invoked after the View is inserted into the
     * document DOM.  The application can put logic that requires the DOM being
     * attached here.
     * This method might be called multiple times - after the View is created
     * and inserted into the DOM and after the View is reconnected
     * after being disconnected.
     */
    connected() {
        // implement if needed
    }
    // public formatDate(dateStr :String) {
    //   return new Date().format('MM/DD/YY');
    // }
    /**
     * Optional ViewModel method invoked after the View is disconnected from the DOM.
     */
    disconnected() {
        // implement if needed
    }
    /**
     * Optional ViewModel method invoked after transition to the new View is complete.
     * That includes any possible animation between the old and the new View.
     */
    transitionCompleted() {
        // implement if needed
    }
}
exports.default = RemarksViewModel;
//# sourceMappingURL=Remarks.js.map