"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Task_1 = require("../ampCommon/tasklist/Task");
const ko = require("knockout");
const ArrayDataProvider = require("ojs/ojarraydataprovider");
require("ojs/ojtable");
require("ojs/ojselectcombobox");
require("ojs/ojdialog");
const KnockoutTemplateUtils = require("ojs/ojknockouttemplateutils");
require("ojs/ojselectsingle");
const ModuleUtils = require("ojs/ojmodule-element-utils");
const CostApproach_1 = require("../viewModels/CostApproach");
class ActivityViewModel {
    constructor() {
        this.group = ko.observable();
        this.activity = ko.observable();
        this.addActivity = (event) => {
            let self = this;
            const newActitvity = {
                ACTIVITY: self.activity(),
                STAGE: "Appraisal",
                UI_RESOURCE_ID: "CostApproach",
                OPERATION_FLAG: "I",
                ACTIVITY_INST_ID: null,
                ACTIVITY_PAYLOAD: null,
                ROW_ID: self.task().activityStageArray().length + 1
            };
            self.task().workUnitDetailsList()[0].WU_AO[0].WU_ACTIVITIES.push(newActitvity);
            self.task().filterActivities("Appraisal");
            document.getElementById('addActivityDialog').close();
        };
        this.editAdvanceActivity = (actInstID, rowID) => {
            let self = this;
            let editIdentifier = (actInstID ? actInstID : rowID);
            self.selectedActivity = self.task().workUnitDetailsList()[0].WU_AO[0].WU_ACTIVITIES
                .filter(data => (data.ACTIVITY_INST_ID ? data.ACTIVITY_INST_ID : data.ROW_ID)
                === editIdentifier)[0];
            let activityName = self.selectedActivity.UI_RESOURCE_ID;
            let view = "views/" + activityName + ".html";
            let model = "viewModels/" + activityName;
            let advActivityPromise = Promise.all([
                ModuleUtils.createView({ "viewPath": view }),
                ModuleUtils.createViewModel({ "viewModelPath": model })
            ]);
            advActivityPromise.then((values) => {
                this.advActivityModuleConfig({ "view": values[0], "viewModel": values[1].default });
            });
            self.loadCostApproachPayload(self.selectedActivity.ACTIVITY_PAYLOAD);
        };
        this.loadCostApproachPayload = (activityPayLoad) => {
            CostApproach_1.default.loadCostApproachDetails(activityPayLoad);
            document.getElementById('editAdvActivityDialog').open();
        };
        this.prepareCostApproachPayload = () => {
            let self = this;
            let activityPayload;
            activityPayload = CostApproach_1.default.prepareCostApproachPayload();
            self.selectedActivity.ACTIVITY_PAYLOAD = activityPayload;
            document.getElementById('editAdvActivityDialog').close();
        };
        this.closeAdvActivity = (event) => {
            document.getElementById('editAdvActivityDialog').close();
        };
        let self = this;
        self.task = ko.observable(Task_1.Task.getInstance());
        self.activityDataProvider = ko.observable();
        self.activityColumnArray = ko.observableArray([
            { "headerText": "", "field": "", "renderer": KnockoutTemplateUtils.getRenderer("activity_erase", true) },
            { "headerText": "", "field": "", "renderer": KnockoutTemplateUtils.getRenderer("activity_edit", true) },
            { "headerText": "Activity", "field": "ACTIVITY", "renderer": KnockoutTemplateUtils.getRenderer("activity_name", true) },
            { "headerText": "Comments", "field": "", "renderer": KnockoutTemplateUtils.getRenderer("activity_comment", true) },
            { "headerText": "Date Completed", "field": "", "renderer": KnockoutTemplateUtils.getRenderer("activity_datecompleted", true) },
            { "headerText": "Duration", "field": "", "renderer": KnockoutTemplateUtils.getRenderer("activity_duration", true) },
            { "headerText": "Overtime", "field": "", "renderer": KnockoutTemplateUtils.getRenderer("activity_overtime", true) },
            { "headerText": "Completed", "field": "" }
        ]);
        self.groupDP = ko.observable();
        self.activityDP = ko.observable();
        let groups = [
            { value: 'Cost Approach', label: 'Cost Approach' }
        ];
        let activities = [
            { value: 'Cost Approach - Outcome', label: 'Cost Approach - Outcome' }
        ];
        self.groupDP(new ArrayDataProvider(groups, { idAttribute: 'value' }));
        self.activityDP(new ArrayDataProvider(activities, { idAttribute: 'value' }));
        ko.computed(() => {
            self.activityDataProvider(new ArrayDataProvider(self.task().activityStageArray(), { idAttribute: '' }));
        });
        self.advActivityModuleConfig = ko.observable({ "view": [], "viewModel": null });
    }
    openActivity(event) {
        document.getElementById('addActivityDialog').open();
    }
    close(event) {
        document.getElementById('addActivityDialog').close();
    }
    connected() {
    }
}
exports.default = ActivityViewModel;
//# sourceMappingURL=Activity.js.map