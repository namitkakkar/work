"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ko = require("knockout");
const ResponsiveUtils = require("ojs/ojresponsiveutils");
const ResponsiveKnockoutUtils = require("ojs/ojresponsiveknockoututils");
require("ojs/ojmodule-element");
const ModuleUtils = require("ojs/ojmodule-element-utils");
require("ojs/ojknockout");
const Task_1 = require("./ampCommon/tasklist/Task");
require("jet-composites/amp-selectone-choice/1.0.0/loader");
class FooterLink {
    constructor({ name, id, linkTarget }) {
        this.name = name;
        this.id = id;
        this.linkTarget = linkTarget;
    }
}
class RootViewModel {
    constructor() {
        // media queries for repsonsive layouts
        let self = this;
        this.propTypeLov = ko.observable('');
        self.task = ko.observable();
        let smQuery = ResponsiveUtils.getFrameworkQuery("sm-only");
        if (smQuery) {
            self.smScreen = ResponsiveKnockoutUtils.createMediaQueryObservable(smQuery);
        }
        // header
        self.headerModuleConfig = ko.observable({ view: [], viewModel: null });
        self.dashboardModuleConfig = ko.observable({ view: [], viewModel: null });
        // application Name used in Branding Area
        self.appName = ko.observable("Los Angeles Assessor County");
        // user Info used in Global Navigation area
        self.userLogin = ko.observable("nikita.charakhawala@oracle.com");
        // footer
        self.footerLinks = ko.observableArray([
            new FooterLink({ name: "Disclaimer", id: "Disclaimer", linkTarget: "#" }),
            new FooterLink({ name: "FAQs", id: "FAQs", linkTarget: "#" }),
            new FooterLink({ name: "Contact Us", id: "ContactUs", linkTarget: "#" }),
            new FooterLink({ name: "Version 3.2.0.0 OPC ALT Test 3", id: "version", linkTarget: "#" }),
            new FooterLink({ name: "2016 - Present © Los Angeles County Office of the Assessor", id: "yourPrivacyRights", linkTarget: "#" })
        ]);
        //Dashboard Module
        let dashboardPromise = Promise.all([
            ModuleUtils.createView({ "viewPath": "views/Dashboard.html" }),
            ModuleUtils.createViewModel({ "viewModelPath": "viewModels/Dashboard" })
        ]);
        dashboardPromise.then((values) => {
            self.dashboardModuleConfig({ "view": values[0], "viewModel": values[1].default });
        });
        //Header Module
        let headerPromise = Promise.all([
            ModuleUtils.createView({ "viewPath": "views/Header.html" }),
            ModuleUtils.createViewModel({ "viewModelPath": "viewModels/Header" })
        ]);
        headerPromise.then((values) => {
            self.headerModuleConfig({ "view": values[0], "viewModel": values[1].default });
        });
    }
    loadModule() {
        let self = this;
        self.task(Task_1.Task.getInstance());
        self.task().getWorkUnitDetails("WU1910-1090122");
    }
}
exports.default = new RootViewModel();
//# sourceMappingURL=appController.js.map