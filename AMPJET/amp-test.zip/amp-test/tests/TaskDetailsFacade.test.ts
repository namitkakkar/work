import * as ko from "knockout";
import { } from 'jasmine';
import {TaskDetailsFacade, IWorkUnitDetails} from '../src/ts/task-details/ampCommon/tasklist/facade/TaskDetailsFacade';

declare var $: any;

describe('TaskDetails', function() {
    it('workUnitDetails', function() {
        let taskDetailsFacade : TaskDetailsFacade;
        taskDetailsFacade = new TaskDetailsFacade();
        let workUnitDetailsList: ko.ObservableArray<IWorkUnitDetails>;
        taskDetailsFacade.getWorkUnitDetails("WU1910-1090122", function(data){
            workUnitDetailsList = workUnitDetailsList(data);
         });
      expect(workUnitDetailsList.length).toBeGreaterThan(0);
    });
  });