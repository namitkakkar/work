import * as ko from "knockout";
import { } from 'jasmine';
import {CostApproach} from '../src/ts/task-details/viewModels/CostApproach';
import {ActivityPayload} from "../src/ts/task-details/model/ActivityPayload";
import ArrayDataProvider = require("ojs/ojarraydataprovider");

declare var $: any;

describe('CostApproach', function() {
    it('prepareCostApproachPayload', function() {
        let costApproach : CostApproach;
        costApproach = new CostApproach();
        let activityPaylaodData: ActivityPayload;
        activityPaylaodData = costApproach.prepareCostApproachPayload();
        expect(activityPaylaodData.ValueSetList.length).toBeGreaterThan(0);
    });
  });