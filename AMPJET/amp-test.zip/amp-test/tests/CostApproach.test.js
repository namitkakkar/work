"use strict";
exports.__esModule = true;
var CostApproach_1 = require("../src/ts/task-details/viewModels/CostApproach");
describe('CostApproach', function () {
    it('prepareCostApproachPayload', function () {
        var costApproach;
        costApproach = new CostApproach_1.CostApproach();
        var activityPaylaodData;
        activityPaylaodData = costApproach.prepareCostApproachPayload();
        expect(activityPaylaodData.ValueSetList.length).toBeGreaterThan(0);
    });
});
