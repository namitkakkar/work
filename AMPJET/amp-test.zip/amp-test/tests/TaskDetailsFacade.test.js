"use strict";
exports.__esModule = true;
var TaskDetailsFacade_1 = require("../src/ts/task-details/ampCommon/tasklist/facade/TaskDetailsFacade");
describe('TaskDetails', function () {
    it('workUnitDetails', function () {
        var taskDetailsFacade;
        taskDetailsFacade = new TaskDetailsFacade_1.TaskDetailsFacade();
        var workUnitDetailsList;
        taskDetailsFacade.getWorkUnitDetails("WU1910-1090122", function (data) {
            workUnitDetailsList = workUnitDetailsList(data);
        });
        expect(workUnitDetailsList.length).toBeGreaterThan(0);
    });
});
