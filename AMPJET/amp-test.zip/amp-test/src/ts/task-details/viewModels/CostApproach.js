"use strict";
exports.__esModule = true;
var ko = require("knockout");
var AdvancedActivityUtil_1 = require("../util/AdvancedActivityUtil");
var AdvancedActivityConstants_1 = require("../util/AdvancedActivityConstants");
var ArrayDataProvider = require("ojs/ojarraydataprovider");
var CostApproach = /** @class */ (function () {
    function CostApproach() {
        var _this = this;
        this.activityName = ko.observable();
        this.eventType = ko.observable('CH');
        this.valuationDate = ko.observable();
        this.landValue = ko.observable(0);
        this.improvementValue = ko.observable(0);
        this.ppValue = ko.observable(0);
        this.fixtureValue = ko.observable(0);
        this.totalRealProperty = ko.observable(0);
        this.fixtureTotal = ko.observable(0);
        this.PAYLOAD_LIST = ko.observableArray([]);
        this.loadCostApproachDetails = function (activityPayload) {
            var self = _this;
            if (activityPayload && (activityPayload.ValueSetList && activityPayload.ValueSetList.length > 0)) {
                var keyPairList = activityPayload.ValueSetList[0].ValueSet;
                if (keyPairList && keyPairList.length > 0) {
                    for (var val in keyPairList) {
                        switch (keyPairList[val].key) {
                            case 'EventType': {
                                self.eventType(keyPairList[val].value);
                                break;
                            }
                            case 'ValuationDate': {
                                self.valuationDate(keyPairList[val].value);
                                break;
                            }
                            case 'LandValue': {
                                self.landValue(keyPairList[val].value);
                                break;
                            }
                            case 'ImprovementValue': {
                                self.improvementValue(keyPairList[val].value);
                                break;
                            }
                            case 'PersonalPropertyValue': {
                                self.ppValue(keyPairList[val].value);
                                break;
                            }
                            case 'FixtureValue': {
                                self.fixtureValue(keyPairList[val].value);
                                break;
                            }
                            default: {
                                console.log("Key Not Found");
                                break;
                            }
                        }
                    }
                }
            }
            else {
                self.eventType('');
                self.valuationDate();
                self.landValue(0);
                self.improvementValue(0);
                self.ppValue(0);
                self.fixtureValue(0);
            }
        };
        this.prepareCostApproachPayload = function () {
            var self = _this;
            var activityPaylaodData = {
                name: "Cost Approach",
                ValueSetList: []
            };
            var keyValueList = [];
            keyValueList.push(AdvancedActivityUtil_1.AdvancedActivityUtil.getKeyValueObj(AdvancedActivityConstants_1.AdvancedActivityConstants.EVENT_TYPE, self.eventType()));
            keyValueList.push(AdvancedActivityUtil_1.AdvancedActivityUtil.getKeyValueObj(AdvancedActivityConstants_1.AdvancedActivityConstants.VAL_DATE, self.valuationDate()));
            keyValueList.push(AdvancedActivityUtil_1.AdvancedActivityUtil.getKeyValueObj(AdvancedActivityConstants_1.AdvancedActivityConstants.LAND_VALUE, self.landValue()));
            keyValueList.push(AdvancedActivityUtil_1.AdvancedActivityUtil.getKeyValueObj(AdvancedActivityConstants_1.AdvancedActivityConstants.IMPROVEMENT_VALUE, self.improvementValue()));
            keyValueList.push(AdvancedActivityUtil_1.AdvancedActivityUtil.getKeyValueObj(AdvancedActivityConstants_1.AdvancedActivityConstants.PERSONALPROPERTY_VALUE, self.ppValue()));
            keyValueList.push(AdvancedActivityUtil_1.AdvancedActivityUtil.getKeyValueObj(AdvancedActivityConstants_1.AdvancedActivityConstants.FIXTURE_VALUE, self.fixtureValue()));
            var valuesetList = {
                name: "Cost Approach",
                ValueSet: keyValueList
            };
            activityPaylaodData.ValueSetList.push(valuesetList);
            return activityPaylaodData;
        };
        var self = this;
        var browsers = [
            { value: 'IE', label: 'Internet Explorer' },
            { value: 'FF', label: 'Firefox' },
            { value: 'CH', label: 'Chrome' },
            { value: 'OP', label: 'Opera' },
            { value: 'SA', label: 'Safari' }
        ];
        self.browsersDP = new ArrayDataProvider(browsers, { keyAttributes: 'value' });
        ko.computed(function () {
            var self = _this;
            self.totalRealProperty(+self.landValue() + +self.improvementValue());
            self.fixtureTotal(+self.ppValue() + +self.fixtureValue());
        });
    }
    return CostApproach;
}());
exports.CostApproach = CostApproach;
exports["default"] = new CostApproach();
