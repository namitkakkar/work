import * as ko from "knockout";
import "ojs/ojtable";
import { oj } from "@oracle/oraclejet/dist/types";
import "ojs/ojmodel";
import "ojs/ojlabel";
import "ojs/ojbutton";
import "ojs/ojinputtext";
import "ojs/ojdatetimepicker";
import "ojs/ojinputnumber"
import "ojs/ojcore"
// import { IRemarks } from "../models/interfaces/IRemarks";
import ArrayDataProvider = require("ojs/ojarraydataprovider");
import 'ojs/ojdialog';
declare var require: any;

class RemarksViewModel {
    public remarksObservableArray: ko.ObservableArray = ko.observableArray([]);
    remarksDataObservable: ko.Observable = ko.observable();
    workUnitNumber: ko.Observable<string> = ko.observable("76272872");
    noteslength: ko.Observable<number> = ko.observable();
    constructor() {
        var self = this;
        fetch("http://iampwtd201.assessor.lacounty.gov:7777/soa-infra/resources/amp/RemarkAPIs/RemarkRestAPIs/GetRemarks?ModuleName=GCM_WU_INST&ParentId=693", {
            //        headers: {
            //   "Access-Control-Allow-Origin":"*",
            //   "content-type": "application/json",
            //   // "Authorization":"Basic QzE3ODY2MjpQYXNzd29yZDEyMw=="
            // }
        }).then(res => res.json())
            .then(res => {
                console.log(res);
                console.log(res.WU_NOTES);
                const resResult: IRemarks[] = <IRemarks[]>res.WU_NOTES;
                this.remarksObservableArray(resResult);
                console.log(this.remarksObservableArray());
                this.remarksDataObservable(new ArrayDataProvider(this.remarksObservableArray, { keyAttributes: 'REMARKS_ID' }));
                this.remarksObservableArray(resResult);
                console.log(this.remarksObservableArray());
                this.noteslength(this.remarksObservableArray().length);
            }
            ).catch(error => {
                console.log("ERROR");
                console.log(error);
            });
        //   console.log( new Date("2016-01-17T08:44:29+0100"));
    }



    /**
     * Optional ViewModel method invoked after the View is inserted into the
     * document DOM.  The application can put logic that requires the DOM being
     * attached here.
     * This method might be called multiple times - after the View is created
     * and inserted into the DOM and after the View is reconnected
     * after being disconnected.
     */
    connected(): void {
        // implement if needed
    }


    // public formatDate(dateStr :String) {
    //   return new Date().format('MM/DD/YY');
    // }
    /**
     * Optional ViewModel method invoked after the View is disconnected from the DOM.
     */
    disconnected(): void {
        // implement if needed
    }

    /**
     * Optional ViewModel method invoked after transition to the new View is complete.
     * That includes any possible animation between the old and the new View.
     */
    transitionCompleted(): void {
        // implement if needed
    }
}

export default RemarksViewModel;


export interface IRemarks {
    CREATED_BY: string,
    CREATED_DATE: string,
    REMARKS_ID: string,
    REMARKS: string,
    CREATED_USER: string,
    REMARKS_SUBJECT: string
} 