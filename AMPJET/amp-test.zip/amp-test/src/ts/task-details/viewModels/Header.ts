class headerViewModel{
    constructor(){

    }
}
export default headerViewModel;