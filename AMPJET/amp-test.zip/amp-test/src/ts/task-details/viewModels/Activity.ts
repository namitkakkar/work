import { Task } from "../ampCommon/tasklist/Task";
import * as ko from "knockout";
import ArrayDataProvider = require("ojs/ojarraydataprovider");
import "ojs/ojtable";
import "ojs/ojselectcombobox";
import 'ojs/ojdialog';
import { ojDialog } from 'ojs/ojdialog';
import { ojButtonEventMap } from 'ojs/ojbutton';
import * as KnockoutTemplateUtils from "ojs/ojknockouttemplateutils";
import {IWuActivityDetails} from "../ampCommon/tasklist/facade/TaskDetailsFacade";

import "ojs/ojselectsingle";
import { ojModule } from "ojs/ojmodule-element";
import * as ModuleUtils from "ojs/ojmodule-element-utils";
import CostApproach from "../viewModels/CostApproach";
import {ActivityPayload} from "../model/ActivityPayload";

class ActivityViewModel {
    task: ko.Observable<Task>;
    activityDataProvider: ko.Observable<ArrayDataProvider<string, string>>;
    activityColumnArray: ko.ObservableArray<any>;

    groupDP: ko.Observable<ArrayDataProvider<string, string>>;
    activityDP: ko.Observable<ArrayDataProvider<string, string>>;
    group: ko.Observable<string> = ko.observable();
    activity: ko.Observable<string> = ko.observable();
    advActivityModuleConfig: ko.Observable<ojModule["config"]>;
    selectedActivity: IWuActivityDetails;

    constructor() {
        let self = this;
        self.task = ko.observable(Task.getInstance());
        self.activityDataProvider=ko.observable();
        self.activityColumnArray = ko.observableArray([
            { "headerText": "", "field": "", "renderer":KnockoutTemplateUtils.getRenderer("activity_erase", true) },
            { "headerText": "", "field": "" , "renderer": KnockoutTemplateUtils.getRenderer("activity_edit", true)},
            { "headerText": "Activity", "field": "ACTIVITY", "renderer": KnockoutTemplateUtils.getRenderer("activity_name", true)},
            { "headerText": "Comments", "field": "", "renderer": KnockoutTemplateUtils.getRenderer("activity_comment", true)},
            { "headerText": "Date Completed", "field": "", "renderer": KnockoutTemplateUtils.getRenderer("activity_datecompleted", true)},
            { "headerText": "Duration", "field": "", "renderer": KnockoutTemplateUtils.getRenderer("activity_duration", true)},
            { "headerText": "Overtime", "field": "", "renderer": KnockoutTemplateUtils.getRenderer("activity_overtime", true)},
            { "headerText": "Completed", "field": "" }
        ]);

        self.groupDP = ko.observable();
        self.activityDP = ko.observable();

        let groups = [
            { value: 'Cost Approach', label: 'Cost Approach' }
        ];

        let activities = [
            { value: 'Cost Approach - Outcome', label: 'Cost Approach - Outcome' }
        ];

        self.groupDP(new ArrayDataProvider(groups, { idAttribute: 'value' }));
        self.activityDP(new ArrayDataProvider(activities, { idAttribute: 'value' }));

        ko.computed(() => {
            self.activityDataProvider(new ArrayDataProvider(self.task().activityStageArray(), { idAttribute: '' }));
        });

        self.advActivityModuleConfig = ko.observable({"view": [], "viewModel": null});
    }

    public openActivity(event: ojButtonEventMap['ojAction']) {
        (document.getElementById('addActivityDialog') as ojDialog).open();
    }

    public close(event: ojButtonEventMap['ojAction']) {
        (document.getElementById('addActivityDialog') as ojDialog).close();
    }

    public addActivity = (event: ojButtonEventMap['ojAction']) => { 
        let self = this;
        const newActitvity: IWuActivityDetails = {
            ACTIVITY : self.activity(),
            STAGE : "Appraisal",
            UI_RESOURCE_ID : "CostApproach",
            OPERATION_FLAG: "I",
            ACTIVITY_INST_ID : null,
            ACTIVITY_PAYLOAD: null,
            ROW_ID: self.task().activityStageArray().length + 1
        };
        
        self.task().workUnitDetailsList()[0].WU_AO[0].WU_ACTIVITIES.push(newActitvity);
        self.task().filterActivities("Appraisal");

       (document.getElementById('addActivityDialog') as ojDialog).close();
    }

    public editAdvanceActivity = (actInstID: number, rowID: number) => {
        let self = this;

        let editIdentifier = (actInstID ? actInstID : rowID);

        self.selectedActivity = self.task().workUnitDetailsList()[0].WU_AO[0].WU_ACTIVITIES
                        .filter(data => (data.ACTIVITY_INST_ID ? data.ACTIVITY_INST_ID : data.ROW_ID)
                                        === editIdentifier)[0];

        let activityName = self.selectedActivity.UI_RESOURCE_ID;
        let view = "views/"+activityName+".html";
        let model = "viewModels/"+activityName;

        let advActivityPromise: Promise<any> = Promise.all([
            ModuleUtils.createView({ "viewPath": view }),
            ModuleUtils.createViewModel({ "viewModelPath": model })
        ]);
          
        advActivityPromise.then((values) => {
            this.advActivityModuleConfig({ "view": values[0], "viewModel": values[1].default });
        });

        self.loadCostApproachPayload(self.selectedActivity.ACTIVITY_PAYLOAD);
    }

    public loadCostApproachPayload = (activityPayLoad: ActivityPayload) => {
        CostApproach.loadCostApproachDetails(activityPayLoad);
        (document.getElementById('editAdvActivityDialog') as ojDialog).open();
    }

    public prepareCostApproachPayload = () => {
        let self = this;
        let activityPayload: ActivityPayload
        
        activityPayload = CostApproach.prepareCostApproachPayload();
        self.selectedActivity.ACTIVITY_PAYLOAD = activityPayload;

        (document.getElementById('editAdvActivityDialog') as ojDialog).close();
    }

    public closeAdvActivity = (event: ojButtonEventMap['ojAction']) => { 
        (document.getElementById('editAdvActivityDialog') as ojDialog).close();
    }
    
    connected(): void {
    }
  
}
export default ActivityViewModel;