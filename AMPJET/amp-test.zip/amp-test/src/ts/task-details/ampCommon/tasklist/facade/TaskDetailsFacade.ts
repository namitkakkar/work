import {ActivityPayload} from "../../../model/ActivityPayload"

export class TaskDetailsFacade {

  getWorkUnitDetails(wuNumber: string, callback: Function): void {
    $.ajax({
      type: "GET",
      //url: "http://iampwtd201.assessor.lacounty.gov:7777/soa-infra/resources/amp/WorkUnitDetailsAPI/WorkUnitDetailsProcessAPI/wu?clientid=TEST_GET_WU_DETAILS&wu=YES&wuinstid=89951&wunumber=WU1909-1089950&ao=YES&activities=YES&activityinstid=7349703&buseventid=&determiniationinstid=273158&determiniations=YES&instlogid=267224&instlog=YES&rtcodesinstid=7960&rtcodes=rtcodes14&routinginstid=264868&routing=YES",
       //url:"http://iampwtd201.assessor.lacounty.gov:7780/ords/amp_core/wu/gcm_wu_inst_api?P_CLIENT_ID=TEST_GET_WU_DETAILS&P_GET_WU_CASE=YES&P_GET_WU_ACT=YES&P_GET_WU_DETR=YES&P_GET_RTCODES=YES&P_GET_ROUT_REC=YES&P_GET_WU_INST_LOG=NO&P_GET_WU_AO=YES&P_WU_INST_ID=89951&P_WU_NUMBER=&P_WU_ROUTING_INST_ID=264868&P_WU_ACT_INST_ID=7349703&P_WU_DETR_INST_ID=273158&P_WU_RTCODE_INST_ID=7960&P_WU_INST_LOG_ID=267224&P_VERSION=V1",
       url:"http://localhost:8010/proxy/soa-infra/resources/amp/WorkUnitDetailsAPI/WorkUnitDetailsProcessAPI/wu?clientid=TEST_GET_WU_DETAILS&wu=YES&wuinstid=89951&wunumber=&ao=YES&activities=YES&activityinstid=7349703&buseventid=&determiniationinstid=&determiniations=YES&instlogid=&instlog=NO&rtcodesinstid=&rtcodes=YES&routinginstid=&routing=&version=V1&ain=&caseNumber=&rowCount=&sortOrderType=",
      headers: {
       // "Authorization": "Basic QzE4ODg2OTpQYXNzd29yZDEyMw==",
        "Access-Control-Allow-Origin":"*",
        "content-type": "application/json"
      },
      beforeSend: function (xhr) {
        xhr.setRequestHeader ("Authorization", "Basic " + btoa('C178662' + ":" + 'Password123'));
    },
      //url: " http://localhost:8010/proxy/soa-infra/resources/amp/WorkUnitDetailsAPI/WorkUnitDetailsProcessAPI/wu?clientid=TEST_GET_WU_DETAILS&wu=YES&wuinstid=89951&wunumber=WU1909-1089950&ao=YES&activities=YES&activityinstid=7349703&buseventid=&determiniationinstid=273158&determiniations=YES&instlogid=267224&instlog=YES&rtcodesinstid=7960&rtcodes=rtcodes14&routinginstid=264868&routing=YES",
      success: function (payload) {
        callback(<IWorkUnitDetails>payload.WU_DETAILS);
      }
    });
  }

  saveWorkUnitDetails(data, callback: Function): void {
    const payload: IWU_DETAILS = {
      "WU_DETAILS" : data
    }

    console.log(JSON.stringify(payload));

    let settings = {
      "url": "http://localhost:8010/proxy/soa-infra/resources/amp/WorkUnitDetailsAPI/WorkUnitDetailsProcessAPI/wuapi ",
      "method": "POST",
      "timeout": 0,
      "headers": {
        "Content-Type": "application/json",
        "Authorization": "Basic T0FfTlJQSUMxOlBhc3N3b3JkMTIz"
      },
      "data": JSON.stringify(payload),
    };

    $.ajax(settings).done(function(response) {
      console.log(response);
      callback(<IWorkUnitDetails>response);
    }).catch(function(ex){
      console.log(ex);
    });

  }

  filterActivities(stageName : string, activityList:IWuActivityDetails[]) : Array<any>{
    let filterActivity:Array<any>=new Array();
    if(activityList!==undefined && activityList.length>0){
    activityList.forEach((activity)=>{
      if(activity!==null && activity.STAGE==stageName){
       const {ACTIVITY,ACTIVITY_INST_ID,UI_RESOURCE_ID, ACTIVITY_CREATED_DATE, 
                                                ACTIVITY_PAYLOAD, STAGE, ROW_ID} = activity;
       filterActivity.push({
         ACTIVITY:ACTIVITY+' - '+ (ACTIVITY_INST_ID != null ? ACTIVITY_INST_ID : ROW_ID),
         ACTIVITY_INST_ID: ACTIVITY_INST_ID,
         UI_RESOURCE_ID: UI_RESOURCE_ID,
         ACTIVITY_CREATED_DATE: ACTIVITY_CREATED_DATE,
         ACTIVITY_PAYLOAD : ACTIVITY_PAYLOAD,
         STAGE :STAGE,
         ROW_ID: ROW_ID
        });
      }
    });
    return filterActivity;
  }
}
}

export interface IWU_DETAILS {
  "WU_DETAILS" : IWorkUnitDetails;
}

export interface IWorkUnitDetails {
  WU_INST_ID: string;
  WU_NUMBER: string;
  WORK_UNIT_TYPE: string;
  STATUS: string;
  ASSIGNMENT_POOL: string;
  BPM_INSTANCE_ID: string;
  CASE_ID: string;
  CASE_NUMBER: string;
  BUSINESS_EVENT_ID: string;
  BUSINESS_EVENT_DATE: string;
  EVENT_NAME: string;
  EVENT_NUMBER: string;
  CATEGORY: string;
  SUBCATEGORY: string;
  CREATED_BY: string;
  CREATED_DATE: string;
  MODIFIED_BY: string;
  MODIFIED_DATE: string;
  WU_AO: IAinDetails[];
}
export interface IAinDetails {
  AIN: string;
  ASMT_OBJ_ID: string;
  PROPERTY_TYPE: string;
  WU_INST_ID: string;
  WU_INST_AO_ID: string;
  WU_ACTIVITIES: IWuActivityDetails[];
  WU_DETERMINATIONS : IDeterminationDetails[];
  WU_RTCODES : IWURTCodesDetails[];
  WU_INST_LOG : IWuInstLogDetails[];
}
export interface IWuActivityDetails {
  ACTIVITY_INST_ID: number;
  WU_INST_AO_ID?: string;
  GCM_ACTIVITY_ID?: string,
  STAGE: string;
  ACTIVITY: string;
  GROUP_NAME?: string;
  UI_RESOURCE_ID: string;
  WU_ROUTING_INST_ID?: string;
  OPERATION_FLAG?: string;
  INSERT_LOG_FLAG?: string;
  PRE_CONFIGURED_FLAG?: string;
  PROGRAM_NAME?: string;
  POINTS?: string;
  ACTIVITY_CREATED_BY?: string;
  ACTIVITY_CREATED_DATE?: string;
  AIN?: string;
  ASMT_OBJ_ID?: string;
  PROPERTY_TYPE?: string;
  WU_INST_ID?: string;

  ROW_ID ?: Number;
  ACTIVITY_PAYLOAD ?: ActivityPayload;
}
export interface IDeterminationDetails{
  DETR_INST_ID: string;
  WU_INST_AO_ID: string;
  WU_ROUTING_INST_ID: string;
  STAGE:string;
  NAME:string;
  DISPLAY_TYPE:string;
  DETR_CREATED_BY:string;
  DETR_CREATED_DATE:string;
  DETR_FLAG: string;
  OPERATION_FLAG: string;
  INSERT_LOG_FLAG:string;
}
export interface IWURTCodesDetails{
  RTC_INST_ID : string;
  WU_INST_AO_ID : string;
  WU_ROUTING_INST_ID : string;
  STAGE : string;
  NAME : string;
  REFERENCE_NUMBER : string;
  REFERENCE_TYPE : string;
  REFERENCE_DESC : string;
  URL : string;
  INSERT_LOG_FLAG : string;
  PRE_CONFIGURED_FLAG : string;
  RTCODE_CREATED_BY : string;
  RTCODE_CREATED_DATE: string;
  OPERATION_FLAG : string;
  RTC_FLAG : string;
}
export interface IWURoutingDetails{
  ROUTING_ID : string;
  WU_INST_ID : string;
  CREATED_BY : string;
  CREATED_DATE : string;
  POOL_NAME : string;
  ASSIGN_POOL_NAME : string;
  PERFORM_POOL_NAME : string;
  QC_POOL_NAME : string;
  ASSIGN_FLAG : string;
  QC_ACTION : string;
  SEQ_NUMBER : string;
  GCM_ASGN_POOL_CONFIG_ID : string;
}
export interface IWuInstLogDetails{
  WU_INST_LOG_ID : string;
  CREATED_BY : string;
  CREATED_DATE : string;
  STATUS : string;
  CURRENT_USER_ID : string;
  GCM_WU_INST_ID : string;
}