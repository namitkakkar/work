import * as ko from "knockout";
import { TaskDetailsFacade, IWorkUnitDetails } from "./facade/TaskDetailsFacade";
export class Task{
    private static instance: Task;
    workUnitDetailsList: ko.ObservableArray<IWorkUnitDetails>;
    activityStageArray: ko.ObservableArray<any>;
    taskDetailsFacade : TaskDetailsFacade;
    
    private constructor(){
        let self=this;
        self.workUnitDetailsList=ko.observableArray([]);
        self.activityStageArray= ko.observableArray([]);
        self.taskDetailsFacade=new TaskDetailsFacade();
    }

    getWorkUnitDetails(wuNumber: string) : void{
        let self=this;
       
        self.taskDetailsFacade.getWorkUnitDetails(wuNumber, function(data){
           self.workUnitDetailsList(data);
           self.filterActivities('Records Maintenance');
        });
    }

    saveWorkUnitDetails() : void {
        let self = this;
        self.taskDetailsFacade.saveWorkUnitDetails(self.workUnitDetailsList(), function(data) {
        });
    }
    
    filterActivities(stageName: string) : void{
        let self=this;
        if(self.workUnitDetailsList()!==undefined && self.workUnitDetailsList().length>0) {
            self.activityStageArray(self.taskDetailsFacade.filterActivities(stageName, self.workUnitDetailsList()[0].WU_AO[0].WU_ACTIVITIES));
        }
    }

    public static getInstance(): Task{
        if(!Task.instance){
            Task.instance=new Task();
            console.log("New Task Instance");
        }else{
            console.log("Old Task Instance");
        }
        return Task.instance;
    }

}