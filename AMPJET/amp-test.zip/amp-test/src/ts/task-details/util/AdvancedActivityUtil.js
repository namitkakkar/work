"use strict";
exports.__esModule = true;
var AdvancedActivityUtil = /** @class */ (function () {
    function AdvancedActivityUtil() {
    }
    AdvancedActivityUtil.getKeyValueObj = function (key, value) {
        var data = {
            key: key,
            value: value
        };
        return data;
    };
    return AdvancedActivityUtil;
}());
exports.AdvancedActivityUtil = AdvancedActivityUtil;
