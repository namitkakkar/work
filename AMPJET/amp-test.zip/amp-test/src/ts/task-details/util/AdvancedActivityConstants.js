"use strict";
exports.__esModule = true;
var AdvancedActivityConstants = /** @class */ (function () {
    function AdvancedActivityConstants() {
    }
    AdvancedActivityConstants.EVENT_TYPE = "EventType";
    AdvancedActivityConstants.VAL_DATE = "ValuationDate";
    AdvancedActivityConstants.LAND_VALUE = "LandValue";
    AdvancedActivityConstants.IMPROVEMENT_VALUE = "ImprovementValue";
    AdvancedActivityConstants.PERSONALPROPERTY_VALUE = "PersonalPropertyValue";
    AdvancedActivityConstants.FIXTURE_VALUE = "FixtureValue";
    return AdvancedActivityConstants;
}());
exports.AdvancedActivityConstants = AdvancedActivityConstants;
